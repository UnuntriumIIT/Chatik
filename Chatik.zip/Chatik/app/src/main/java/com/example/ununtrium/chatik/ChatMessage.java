package com.example.ununtrium.chatik;

public class ChatMessage {
}
